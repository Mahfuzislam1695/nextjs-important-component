import React from "react";

function Footer() {
	return (
		<div className="bg-red-100 z-50 text-lg">
			Footer <br />
			Footer <br />
			Footer <br />
			Footer <br />
			Footer <br />
			Footer <br />
			Footer <br />
			Footer <br />
		</div>
	);
}

export default Footer;
